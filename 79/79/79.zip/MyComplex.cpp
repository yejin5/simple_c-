
#include "MyComplex.h"

//constructor
myComplex::myComplex(int real, int imag)
{
	realPart = real;
	imaginaryPart = imag;
}

//copy constructor
myComplex::myComplex(const myComplex& number)
{
	realPart = number.realPart;
	imaginaryPart = number.imaginaryPart;
}

//accessor functions
int myComplex::getRealPart() const
{
	return realPart;
}

int myComplex::getImaginaryPart() const
{
	return imaginaryPart;
}

//mutator functions
void myComplex::setRealPart(int real)
{
	realPart = real;
}

void myComplex::setImaginaryPart(int imag)
{
	imaginaryPart = imag;
}

void myComplex::set(int real, int imag)
{
	realPart = real;
	imaginaryPart = imag;
}

//overloaded binary operators
myComplex myComplex::operator+(const myComplex& number) const
{
	int newReal = realPart + number.realPart;
	int newImag = imaginaryPart + number.imaginaryPart;
	return myComplex(newReal, newImag);
}

myComplex myComplex::operator +(int value) const
{
	return myComplex(value) + (*this);
}

//assignment operators
myComplex& myComplex::operator =(const myComplex& number)
{
	this->realPart = number.realPart;
	this->imaginaryPart = number.imaginaryPart;
	return *this;
}

myComplex& myComplex::operator=(int value)
{
	realPart = value;
	imaginaryPart = 0;
	return *this;
}

//overloading comparison operators
bool myComplex::operator==(const myComplex& number) const
{
	return (realPart == number.realPart) && (imaginaryPart == number.imaginaryPart);
}

bool myComplex::operator>(const myComplex& number) const
{
	return norm() > number.norm();
}

//overloaded unary operators
myComplex myComplex::operator -()
{
	return myComplex(-realPart, -imaginaryPart);
}

//private function
int myComplex::norm() const
{
	return realPart*realPart + imaginaryPart*imaginaryPart;
}
